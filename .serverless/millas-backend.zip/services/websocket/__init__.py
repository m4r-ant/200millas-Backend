# WebSocket handlers para seguimiento en tiempo real

